const { createDetails } = require("./detail.controller");

const DetailController = {
  createDetails,
};

module.exports = {
  DetailController,
};
